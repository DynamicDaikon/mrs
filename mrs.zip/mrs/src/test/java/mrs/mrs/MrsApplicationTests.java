package mrs.mrs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MrsApplicationTests {

	@Test
	void contextLoads() {
	}

}
